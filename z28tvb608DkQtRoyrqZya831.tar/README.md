# z28tvb608DkQtRoyrqZya831

## Design Perspective

- Easy to test locally

## How to Use

Execute

- `./.local/run-docker.sh`
- `scripts/bin/ssh.sh ec2-user@mock-host`
