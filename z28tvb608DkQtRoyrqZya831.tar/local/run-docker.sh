#!/bin/bash

set -eu

docker run --rm --workdir /usr/src/app -v `pwd`:/usr/src/app --name python_env -ti python:3.7.4 /bin/bash
